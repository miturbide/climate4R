The dictionaries in this directory correspond to the remote datasets provided by the Santander Meteorology Group through the User Data Gateway.

For a detailed description of the datasets and available variables see:


For more info about the meaning of a vocabulary and a dictionary see:

