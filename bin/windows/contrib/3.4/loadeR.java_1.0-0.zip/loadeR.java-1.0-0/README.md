loadeR.java
===============

Java stuff on which other java-based R packages depend
