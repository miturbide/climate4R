suppressPackageStartupMessages(require("rJava"))

